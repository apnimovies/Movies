const currentJsonEl = document.getElementById('currentJson');
const outputJsonEl = document.getElementById('outputJson');
const jsonStatus = document.getElementById('jsonStatus');
const outputStatus = document.getElementById('outputStatus');
const editStatus = document.getElementById('editStatus');
const itemTypeEl = document.getElementById('itemType');
const movieFields = document.getElementById('movieFields');
const seriesFields = document.getElementById('seriesFields');
const titleListEl = document.getElementById('titleList');
const titleSearchEl = document.getElementById('titleSearch');
const qualityRowsEl = document.getElementById('qualityRows');
const seasonRowsEl = document.getElementById('seasonRows');

let moviesData = [];
let selectedId = '';

function setStatus(element, message, type = 'info') {
  element.textContent = message;
  element.className = `admin-status ${type}`;
}

function slugify(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function getExpectedPosterPath(title) {
  return `assets/posters/${slugify(title)}.jpg`;
}

function normalizeItemFormat(item) {
  const normalized = { ...item };
  normalized.id = slugify(normalized.title);
  normalized.poster = getExpectedPosterPath(normalized.title);
  normalized.posterVersion = normalized.posterVersion || String(Date.now());
  return normalized;
}

function getFormValue(id) {
  return document.getElementById(id).value.trim();
}

function setFormValue(id, value) {
  document.getElementById(id).value = value || '';
}

function parseJsonText(text) {
  const parsed = JSON.parse(text || '[]');
  if (!Array.isArray(parsed)) throw new Error('movies.json ka root [] array hona chahiye.');
  return parsed;
}

function syncFromTextarea() {
  moviesData = parseJsonText(currentJsonEl.value.trim() || '[]');
  refreshAll();
}

function writeJson(data = moviesData) {
  const finalJson = JSON.stringify(data, null, 2);
  currentJsonEl.value = finalJson;
  outputJsonEl.value = finalJson;
}

async function loadCurrentJson() {
  try {
    const response = await fetch('movies.json?v=' + Date.now());
    if (!response.ok) throw new Error('movies.json file nahi mili.');
    moviesData = await response.json();
    if (!Array.isArray(moviesData)) throw new Error('movies.json ka root [] array hona chahiye.');
    writeJson();
    refreshAll();
    setStatus(jsonStatus, 'Current movies.json load ho gaya.', 'success');
  } catch (error) {
    moviesData = [];
    writeJson();
    refreshAll();
    setStatus(jsonStatus, 'Auto load nahi hua. Select movies.json ya manually paste karo.', 'error');
  }
}

function validateMovies(data = moviesData) {
  const issues = [];
  const ids = new Set();

  data.forEach((item, index) => {
    const label = item.title || `Item ${index + 1}`;
    if (!item.id) issues.push(`${label}: id missing`);
    if (ids.has(item.id)) issues.push(`${label}: duplicate id '${item.id}'`);
    ids.add(item.id);
    if (!item.title) issues.push(`${label}: title missing`);
    if (!item.poster) issues.push(`${label}: poster path missing`);

    if (item.title) {
      const expectedId = slugify(item.title);
      const expectedPoster = getExpectedPosterPath(item.title);
      if (item.id !== expectedId) issues.push(`${label}: ID '${expectedId}' hona chahiye`);
      if (String(item.poster || '').replace(/\\/g, '/') !== expectedPoster) {
        issues.push(`${label}: poster path '${expectedPoster}' hona chahiye`);
      }
    }

    if (item.type === 'series') {
      if (!Array.isArray(item.seasons) || !item.seasons.length) issues.push(`${label}: seasons missing`);
      (item.seasons || []).forEach((season, seasonIndex) => {
        if (!Array.isArray(season.episodes) || !season.episodes.length) issues.push(`${label}: ${season.season || 'Season ' + (seasonIndex + 1)} episodes missing`);
        (season.episodes || []).forEach((episode, episodeIndex) => {
          if (!episode.downloadUrl) issues.push(`${label}: episode ${episodeIndex + 1} link missing`);
        });
      });
    } else {
      if (!Array.isArray(item.qualities) || !item.qualities.length) issues.push(`${label}: qualities missing`);
      (item.qualities || []).forEach((quality, qualityIndex) => {
        if (!quality.downloadUrl) issues.push(`${label}: quality ${qualityIndex + 1} link missing`);
      });
    }
  });

  return issues;
}

function updateStats() {
  const issues = validateMovies();
  document.getElementById('totalCount').textContent = moviesData.length;
  document.getElementById('movieCount').textContent = moviesData.filter((item) => item.type !== 'series').length;
  document.getElementById('seriesCount').textContent = moviesData.filter((item) => item.type === 'series').length;
  document.getElementById('issueCount').textContent = issues.length;
}

function refreshTitleList() {
  const query = titleSearchEl.value.trim().toLowerCase();
  const filtered = moviesData.filter((item) => `${item.title || ''} ${item.id || ''} ${item.type || ''}`.toLowerCase().includes(query));

  titleListEl.innerHTML = filtered.length ? filtered.map((item) => `
    <button type="button" class="title-list-item ${item.id === selectedId ? 'active' : ''}" data-id="${item.id}">
      <strong>${item.title || item.id}</strong>
      <span>${item.type === 'series' ? 'Web Series' : 'Movie'} • ${item.category || 'General'}</span>
    </button>
  `).join('') : '<div class="empty-state">No title found.</div>';

  titleListEl.querySelectorAll('[data-id]').forEach((button) => {
    button.addEventListener('click', () => loadItemIntoForm(button.getAttribute('data-id')));
  });
}

function refreshAll() {
  writeJson();
  updateStats();
  refreshTitleList();
}

function createQualityRow(quality = {}) {
  const row = document.createElement('div');
  row.className = 'dynamic-row quality-row';
  row.innerHTML = `
    <input class="quality-value" placeholder="Quality, e.g. 720p" value="${quality.quality || ''}" />
    <input class="size-value" placeholder="Size, e.g. 738 MB" value="${quality.size || ''}" />
    <input class="link-value wide-input" placeholder="Google Drive link" value="${quality.downloadUrl || ''}" />
    <button type="button" class="remove-row danger-mini">×</button>
  `;
  row.querySelector('.remove-row').addEventListener('click', () => row.remove());
  qualityRowsEl.appendChild(row);
}

function createEpisodeRow(container, episode = {}) {
  const row = document.createElement('div');
  row.className = 'dynamic-row episode-row-admin';
  row.innerHTML = `
    <input class="episode-value" placeholder="Episode 1" value="${episode.episode || ''}" />
    <input class="episode-title-value" placeholder="Episode title optional" value="${episode.title || ''}" />
    <input class="episode-quality-value" placeholder="720p" value="${episode.quality || ''}" />
    <input class="episode-size-value" placeholder="379.9 MB" value="${episode.size || ''}" />
    <input class="episode-link-value wide-input" placeholder="Google Drive link" value="${episode.downloadUrl || ''}" />
    <button type="button" class="remove-row danger-mini">×</button>
  `;
  row.querySelector('.remove-row').addEventListener('click', () => row.remove());
  container.appendChild(row);
}

function createSeasonBlock(season = {}) {
  const block = document.createElement('div');
  block.className = 'season-admin-block';
  block.innerHTML = `
    <div class="season-admin-head">
      <input class="season-name-value" placeholder="Season 1" value="${season.season || 'Season 1'}" />
      <button type="button" class="add-episode-btn secondary-btn small-btn">+ Episode</button>
      <button type="button" class="remove-season-btn danger-mini">×</button>
    </div>
    <div class="episode-admin-rows"></div>
  `;
  const episodeContainer = block.querySelector('.episode-admin-rows');
  (season.episodes || []).forEach((episode) => createEpisodeRow(episodeContainer, episode));
  if (!(season.episodes || []).length) createEpisodeRow(episodeContainer, {});
  block.querySelector('.add-episode-btn').addEventListener('click', () => createEpisodeRow(episodeContainer, {}));
  block.querySelector('.remove-season-btn').addEventListener('click', () => block.remove());
  seasonRowsEl.appendChild(block);
}

function clearForm() {
  selectedId = '';
  ['itemId', 'title', 'language', 'category', 'year', 'poster', 'trailerUrl', 'description'].forEach((id) => setFormValue(id, ''));
  setFormValue('language', 'Hindi');
  setFormValue('year', '2026');
  itemTypeEl.value = 'movie';
  qualityRowsEl.innerHTML = '';
  seasonRowsEl.innerHTML = '';
  createQualityRow({});
  toggleTypeFields();
  refreshTitleList();
  setStatus(editStatus, 'New form ready.', 'info');
}

function loadItemIntoForm(id) {
  const item = moviesData.find((entry) => entry.id === id);
  if (!item) return;
  selectedId = id;
  itemTypeEl.value = item.type === 'series' ? 'series' : 'movie';
  setFormValue('itemId', item.id);
  setFormValue('title', item.title);
  setFormValue('language', item.language || 'Hindi');
  setFormValue('category', item.category);
  setFormValue('year', item.year || '2026');
  setFormValue('poster', item.poster);
  setFormValue('trailerUrl', item.trailerUrl);
  setFormValue('description', item.description);

  qualityRowsEl.innerHTML = '';
  seasonRowsEl.innerHTML = '';
  if (item.type === 'series') {
    (item.seasons || []).forEach((season) => createSeasonBlock(season));
    if (!(item.seasons || []).length) createSeasonBlock({});
  } else {
    (item.qualities || []).forEach((quality) => createQualityRow(quality));
    if (!(item.qualities || []).length) createQualityRow({});
  }
  toggleTypeFields();
  refreshTitleList();
  setStatus(editStatus, `${item.title} edit mode me load ho gaya.`, 'success');
}

function buildItemFromForm() {
  const type = itemTypeEl.value;
  const title = getFormValue('title');
  if (!title) throw new Error('Title required hai.');
  const id = slugify(title);
  if (!id) throw new Error('ID required hai.');

  const item = {
    id,
    title,
    type,
    language: getFormValue('language'),
    category: getFormValue('category'),
    year: getFormValue('year'),
    poster: getExpectedPosterPath(title),
    posterVersion: String(Date.now()),
    description: getFormValue('description')
  };

  const trailerUrl = getFormValue('trailerUrl');
  if (trailerUrl) item.trailerUrl = trailerUrl;

  if (type === 'series') {
    item.seasons = Array.from(seasonRowsEl.querySelectorAll('.season-admin-block')).map((seasonBlock, seasonIndex) => {
      const seasonName = seasonBlock.querySelector('.season-name-value').value.trim() || `Season ${seasonIndex + 1}`;
      const episodes = Array.from(seasonBlock.querySelectorAll('.episode-row-admin')).map((row, episodeIndex) => ({
        episode: row.querySelector('.episode-value').value.trim() || `Episode ${episodeIndex + 1}`,
        title: row.querySelector('.episode-title-value').value.trim() || row.querySelector('.episode-value').value.trim() || `Episode ${episodeIndex + 1}`,
        quality: row.querySelector('.episode-quality-value').value.trim(),
        size: row.querySelector('.episode-size-value').value.trim(),
        downloadUrl: row.querySelector('.episode-link-value').value.trim()
      })).filter((episode) => episode.downloadUrl || episode.title || episode.size);
      return { season: seasonName, episodes };
    }).filter((season) => season.episodes.length);

    if (!item.seasons.length) throw new Error('Series ke liye kam se kam 1 episode required hai.');
  } else {
    item.qualities = Array.from(qualityRowsEl.querySelectorAll('.quality-row')).map((row) => ({
      quality: row.querySelector('.quality-value').value.trim(),
      size: row.querySelector('.size-value').value.trim(),
      downloadUrl: row.querySelector('.link-value').value.trim()
    })).filter((quality) => quality.downloadUrl || quality.quality || quality.size);

    if (!item.qualities.length) throw new Error('Movie ke liye kam se kam 1 quality required hai.');
  }

  return item;
}

function saveItem() {
  try {
    syncFromTextarea();
    const item = buildItemFromForm();
    const existingIndex = moviesData.findIndex((entry) => entry.id === selectedId || entry.id === item.id);
    if (existingIndex >= 0) moviesData[existingIndex] = item;
    else moviesData.push(item);
    selectedId = item.id;
    refreshAll();
    setStatus(editStatus, `${item.title} JSON me add/update ho gaya.`, 'success');
    setStatus(outputStatus, 'Full updated movies.json ready hai. Copy ya download karo.', 'success');
  } catch (error) {
    setStatus(editStatus, error.message, 'error');
  }
}

function deleteSelectedItem() {
  if (!selectedId) {
    setStatus(editStatus, 'Pehle existing title select karo.', 'error');
    return;
  }
  const item = moviesData.find((entry) => entry.id === selectedId);
  if (!item) return;
  if (!confirm(`Delete '${item.title}' from JSON?`)) return;
  moviesData = moviesData.filter((entry) => entry.id !== selectedId);
  clearForm();
  refreshAll();
  setStatus(outputStatus, 'Item delete karke full JSON ready hai.', 'success');
}

async function findMissingPosterFiles(data) {
  const missing = [];
  await Promise.all(data.map(async (item) => {
    if (!item.poster) return;
    try {
      const separator = item.poster.includes('?') ? '&' : '?';
      const response = await fetch(`${encodeURI(item.poster)}${separator}check=${Date.now()}`, { cache: 'no-store' });
      if (!response.ok) missing.push(`${item.title}: poster file folder me nahi mili`);
    } catch (error) {
      missing.push(`${item.title}: poster file check nahi ho saki`);
    }
  }));
  return missing;
}

async function validateCurrentJson() {
  try {
    syncFromTextarea();
    setStatus(jsonStatus, 'JSON aur poster files check ho rahi hain...', 'info');
    const issues = [...validateMovies(), ...(await findMissingPosterFiles(moviesData))];
    if (issues.length) {
      setStatus(jsonStatus, `Issues: ${issues.slice(0, 5).join(' | ')}${issues.length > 5 ? ' ...' : ''}`, 'error');
    } else {
      setStatus(jsonStatus, 'JSON valid hai. Koi major issue nahi mila.', 'success');
    }
  } catch (error) {
    setStatus(jsonStatus, error.message, 'error');
  }
}

function formatCurrentJson() {
  try {
    syncFromTextarea();
    moviesData = moviesData.map(normalizeItemFormat);
    writeJson();
    refreshAll();
    setStatus(jsonStatus, 'JSON format ho gaya. IDs aur poster paths automatic correct ho gaye.', 'success');
  } catch (error) {
    setStatus(jsonStatus, error.message, 'error');
  }
}

async function copyOutput() {
  try {
    await navigator.clipboard.writeText(outputJsonEl.value || currentJsonEl.value);
    setStatus(outputStatus, 'JSON copy ho gaya.', 'success');
  } catch (error) {
    setStatus(outputStatus, 'Copy nahi hua. Output manually select karke copy karo.', 'error');
  }
}

function downloadJson() {
  const content = outputJsonEl.value || currentJsonEl.value;
  if (!content.trim()) {
    setStatus(outputStatus, 'Pehle JSON generate/load karo.', 'error');
    return;
  }
  const blob = new Blob([content], { type: 'application/json' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = 'movies.json';
  link.click();
  URL.revokeObjectURL(link.href);
  setStatus(outputStatus, 'movies.json download ho gaya.', 'success');
}

function toggleTypeFields() {
  const isSeries = itemTypeEl.value === 'series';
  movieFields.style.display = isSeries ? 'none' : 'block';
  seriesFields.style.display = isSeries ? 'block' : 'none';
  if (isSeries && !seasonRowsEl.children.length) createSeasonBlock({});
  if (!isSeries && !qualityRowsEl.children.length) createQualityRow({});
}

function handleFileSelect(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      moviesData = parseJsonText(reader.result);
      writeJson();
      refreshAll();
      setStatus(jsonStatus, `${file.name} load ho gaya.`, 'success');
    } catch (error) {
      setStatus(jsonStatus, error.message, 'error');
    }
  };
  reader.readAsText(file);
}

function bindEvents() {
  document.getElementById('loadJsonBtn').addEventListener('click', loadCurrentJson);
  document.getElementById('formatJsonBtn').addEventListener('click', formatCurrentJson);
  document.getElementById('validateBtn').addEventListener('click', validateCurrentJson);
  document.getElementById('jsonFileInput').addEventListener('change', handleFileSelect);
  document.getElementById('addQualityBtn').addEventListener('click', () => createQualityRow({}));
  document.getElementById('addSeasonBtn').addEventListener('click', () => createSeasonBlock({}));
  document.getElementById('saveItemBtn').addEventListener('click', saveItem);
  document.getElementById('deleteItemBtn').addEventListener('click', deleteSelectedItem);
  document.getElementById('newItemBtn').addEventListener('click', clearForm);
  document.getElementById('clearFormBtn').addEventListener('click', clearForm);
  document.getElementById('copyBtn').addEventListener('click', copyOutput);
  document.getElementById('downloadBtn').addEventListener('click', downloadJson);
  itemTypeEl.addEventListener('change', toggleTypeFields);
  titleSearchEl.addEventListener('input', refreshTitleList);
  document.getElementById('title').addEventListener('input', () => {
    setFormValue('itemId', slugify(getFormValue('title')));
    setFormValue('poster', getExpectedPosterPath(getFormValue('title')));
  });
}

bindEvents();
clearForm();
loadCurrentJson();
